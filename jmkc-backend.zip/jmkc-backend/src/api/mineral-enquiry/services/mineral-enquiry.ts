import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::mineral-enquiry.mineral-enquiry');
