import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::mineral-enquiry.mineral-enquiry');
