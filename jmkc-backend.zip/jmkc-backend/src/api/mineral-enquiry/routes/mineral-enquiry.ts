import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::mineral-enquiry.mineral-enquiry');
