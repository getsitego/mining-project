import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::team-member.team-member');
