import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::esg-metric.esg-metric');
