import { factories } from '@strapi/strapi';

export default factories.createCoreController('api::esg-commitment.esg-commitment');
