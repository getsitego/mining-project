import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::esg-commitment.esg-commitment');
