const CONTENT_FIELDS = [
  'title',
  'slug',
  'client',
  'mineral',
  'volume',
  'origin',
  'destination',
  'year',
  'summary',
  'image',
];

export default {
  async beforeCreate(event) {
    const { data } = event.params;

    if (data.publishedAt) {
      return;
    }

    data.approvalStatus = 'pending';
    data.rejectionNote = null;
    data.publishedAt = null;
  },

  async beforeUpdate(event) {
    const { data, where } = event.params;

    const existing = await strapi.db
      .query('api::case-study.case-study')
      .findOne({ where });

    if (!existing) return;

    const isApprovalFieldChange =
      Object.prototype.hasOwnProperty.call(data, 'approvalStatus') ||
      Object.prototype.hasOwnProperty.call(data, 'rejectionNote');

    const contentChanged = CONTENT_FIELDS.some(
      (field) =>
        Object.prototype.hasOwnProperty.call(data, field) &&
        data[field] !== existing[field]
    );

    if (
      existing.approvalStatus === 'approved' &&
      contentChanged &&
      !isApprovalFieldChange
    ) {
      data.approvalStatus = 'pending';
      data.rejectionNote = null;
      data.publishedAt = null;
    }

    if (
      Object.prototype.hasOwnProperty.call(data, 'approvalStatus') &&
      data.approvalStatus !== 'approved'
    ) {
      data.publishedAt = null;
    }
  },
};
