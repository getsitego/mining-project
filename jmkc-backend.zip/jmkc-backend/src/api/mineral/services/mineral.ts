import { factories } from '@strapi/strapi';

export default factories.createCoreService('api::mineral.mineral');
