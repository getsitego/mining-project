// Seed data extracted from mining-project/data/*.ts.
// Lucide icons are stored as iconName strings; the Next.js frontend maps
// them back to components via lib/icon-map.ts.
// `image` fields are the original paths/URLs from the source data; the seed
// runner resolves local paths case-insensitively against ../mining-project/public/
// and downloads remote URLs before uploading them as Strapi media.

export const minerals = [
  {
    slug: 'thermal-coal',
    name: 'Thermal Coal',
    tagline: 'Consistent-grade steam coal for power generation and cement kilns.',
    image: '/min cat1.png',
    color: 'from-zinc-700 to-zinc-900',
    grade: 'GCV 4,200 – 6,500 kcal/kg (ARB)',
    specs: [
      { label: 'Total Moisture', value: '12 – 18%' },
      { label: 'Ash (ADB)', value: '14 – 22%' },
      { label: 'Volatile Matter', value: '26 – 32%' },
      { label: 'Total Sulphur', value: '< 0.8%' },
      { label: 'Size', value: '0 – 50 mm' },
    ],
    origins: ['Odisha (Talcher, Ib Valley)', 'Jharkhand', 'Chhattisgarh'],
    uses: ['Power generation', 'Cement kilns', 'Industrial steam boilers'],
    hsnCode: '27011920',
  },
  {
    slug: 'bauxite',
    name: 'Bauxite',
    tagline: 'Metallurgical & refractory-grade bauxite for aluminium and cement.',
    image: '/min cat3.png',
    color: 'from-orange-700 to-amber-900',
    grade: 'Al₂O₃ 48% – 54%',
    specs: [
      { label: 'Alumina (Al₂O₃)', value: '48 – 54%' },
      { label: 'Silica (SiO₂)', value: '≤ 6%' },
      { label: 'Iron (Fe₂O₃)', value: '≤ 14%' },
      { label: 'TiO₂', value: '≤ 3%' },
      { label: 'Moisture', value: '≤ 12%' },
    ],
    origins: ['Odisha (Koraput)', 'Gujarat (Kutch)', 'Jharkhand'],
    uses: ['Alumina refining', 'Refractory bricks', 'Cement', 'Abrasives'],
    hsnCode: '26060010',
  },
  {
    slug: 'iron-ore',
    name: 'Iron Ore (Fines & Lumps)',
    tagline: 'High-Fe haematite ore, beneficiated and blended to buyer specifications.',
    image: '/min cat2.png',
    color: 'from-red-800 to-red-950',
    grade: 'Fe 58% – 65%',
    specs: [
      { label: 'Fe Content', value: '58 – 65%' },
      { label: 'Silica (SiO₂)', value: '≤ 4.5%' },
      { label: 'Alumina (Al₂O₃)', value: '≤ 3.0%' },
      { label: 'Phosphorus', value: '≤ 0.08%' },
      { label: 'Size', value: 'Fines 0–10mm / Lumps 10–40mm' },
    ],
    origins: ['Odisha (Keonjhar, Sundergarh)', 'Jharkhand', 'Karnataka'],
    uses: ['Steelmaking (BF/DRI)', 'Pellet feedstock', 'Sinter production'],
    hsnCode: '26011150',
  },
  {
    slug: 'manganese-ore',
    name: 'Manganese Ore',
    tagline: 'Metallurgical manganese ore for ferro-alloy production.',
    image: '/Manganese.png',
    color: 'from-slate-700 to-slate-900',
    grade: 'Mn 34% – 46%',
    specs: [
      { label: 'Manganese (Mn)', value: '34 – 46%' },
      { label: 'Iron (Fe)', value: '4 – 10%' },
      { label: 'Silica (SiO₂)', value: '≤ 8%' },
      { label: 'Phosphorus', value: '≤ 0.12%' },
      { label: 'Size', value: '5 – 50 mm' },
    ],
    origins: ['Madhya Pradesh (Balaghat)', 'Maharashtra', 'Odisha'],
    uses: ['Ferro-manganese', 'Silico-manganese', 'Battery-grade (refined)'],
    hsnCode: '26020000',
  },
  {
    slug: 'dolomite',
    name: 'Dolomite',
    tagline: 'Steel-grade dolomite for flux, glass and refractory applications.',
    image: '/Dolomite.png',
    color: 'from-stone-500 to-stone-800',
    grade: 'MgO 18% – 21%, CaO 30% – 32%',
    specs: [
      { label: 'MgO', value: '18 – 21%' },
      { label: 'CaO', value: '30 – 32%' },
      { label: 'SiO₂', value: '≤ 2%' },
      { label: 'R₂O₃', value: '≤ 1.5%' },
      { label: 'Size', value: '10 – 80 mm' },
    ],
    origins: ['Chhattisgarh', 'Andhra Pradesh', 'Madhya Pradesh'],
    uses: ['BF flux', 'Refractory bricks', 'Glass manufacture', 'Agriculture'],
    hsnCode: '25181000',
  },
  {
    slug: 'chromite',
    name: 'Chromite Ore',
    tagline: 'Charge chrome & metallurgical-grade chromite concentrate.',
    image: '/Chromite.png',
    color: 'from-emerald-800 to-slate-900',
    grade: 'Cr₂O₃ 42% – 52%',
    specs: [
      { label: 'Cr₂O₃', value: '42 – 52%' },
      { label: 'Cr:Fe Ratio', value: '1.8 – 2.8' },
      { label: 'Silica', value: '≤ 5%' },
      { label: 'FeO', value: '12 – 18%' },
      { label: 'Size', value: 'Concentrate / lumps 10–40mm' },
    ],
    origins: ['Odisha (Sukinda Valley)'],
    uses: ['Ferro-chrome', 'Stainless steel', 'Refractories'],
    hsnCode: '26100010',
  },
];

export const services = [
  {
    slug: 'mining-operations',
    iconName: 'HardHat',
    title: 'Mining Operations',
    shortDescription:
      'End-to-end mining solutions with advanced machinery and skilled teams.',
    longDescription:
      'From exploration through drilling, blasting, extraction and on-site processing, our mining operations combine modern fleet capacity with experienced crews to deliver consistent grade and tonnage, round the clock.',
    image: '/service3.jpg',
    highlights: [
      '24/7 open-pit & underground operations',
      'Fleet of 60+ haul trucks, excavators & dozers',
      'On-site crushing, screening & washing plants',
      'Grade-controlled stockpiling with QC sampling',
    ],
  },
  {
    slug: 'logistics-transport',
    iconName: 'Truck',
    title: 'Logistics & Transport',
    shortDescription:
      'Safe and timely transportation of minerals from mines to ports and beyond.',
    longDescription:
      'Our dedicated pit-to-port logistics network spans dedicated fleet, rail tie-ins and bonded warehousing. Real-time GPS tracking plus a 24/7 control tower keep every consignment visible end-to-end.',
    image: '/service2.jpg',
    highlights: [
      'In-house fleet of 200+ tipper trucks',
      'Rail sidings at 4 strategic loading points',
      'Real-time GPS + weighbridge integration',
      'Bonded CFS warehousing at major ports',
    ],
  },
  {
    slug: 'export-management',
    iconName: 'Ship',
    title: 'Trading',
    shortDescription:
      'Global export support including documentation, customs & compliance.',
    longDescription:
      'We handle the complete export value-chain — from pre-shipment sampling, customs documentation and certificates of origin, to stowage plans, charter coordination and post-shipment reporting — across 15+ destination countries.',
    image: '/M3.jpg',
    highlights: [
      'APEDA-registered export desk',
      'Documentation: Invoice, BL, CoO, SGS/CCIC reports',
      'Charter coordination: Capesize, Panamax, Handymax',
      'DGFT / customs liaison & duty drawback filing',
    ],
  },
  {
    slug: 'equipment-supply',
    iconName: 'Cog',
    title: 'Equipment Supply',
    shortDescription:
      'Supply of heavy machinery and spare parts for mining operations.',
    longDescription:
      'Authorised channel partners for a curated stable of OEMs. We supply new & refurbished equipment, genuine spares, extended AMC contracts and on-site technicians — minimising downtime across your fleet.',
    image: '/service1.jpg',
    highlights: [
      'New & refurbished Cat, Komatsu, Liebherr equipment',
      'Genuine spares inventory at 3 regional hubs',
      'On-site maintenance & AMC contracts',
      'Operator training & certification programs',
    ],
  },
];

export const caseStudies = [
  {
    slug: 'odisha-iron-ore-rotterdam',
    title: '250,000 MT iron-ore fines to Rotterdam',
    client: 'A European steel major',
    mineral: 'Iron Ore Fines (62% Fe)',
    volume: '250,000 MT',
    origin: 'Paradip Port, Odisha',
    destination: 'Rotterdam, Netherlands',
    year: '2024',
    summary:
      "Consolidated three mine sources with strict QC blending to meet the client's 62% Fe spec. Chartered a Capesize vessel for a single through-shipment, cutting lead time by 11 days vs. the previous Panamax plan.",
    image: '/case study1.png',
  },
  {
    slug: 'thermal-coal-vietnam',
    title: 'Multi-port thermal coal supply to Vietnam',
    client: 'A Vietnamese IPP',
    mineral: 'Thermal Coal (GCV 5,200)',
    volume: '180,000 MT across 3 shipments',
    origin: 'Visakhapatnam & Paradip',
    destination: 'Haiphong, Vietnam',
    year: '2024',
    summary:
      'Structured a 3-shipment supply schedule aligned to plant turnaround windows. Real-time stockpile cameras let the client monitor loading progress directly from Hanoi.',
    image: '/case2.png',
  },
  {
    slug: 'bauxite-uae-aluminium',
    title: 'Metallurgical bauxite to a UAE smelter',
    client: 'A Gulf aluminium smelter',
    mineral: 'Bauxite (52% Al₂O₃)',
    volume: '120,000 MT',
    origin: 'Mumbai Port',
    destination: 'Jebel Ali, UAE',
    year: '2023',
    summary:
      'Blended two Odisha deposits to lock in a 52% Al₂O₃ / ≤6% SiO₂ spec. SGS-verified at load and discharge; zero rejection, zero deviation letter issued.',
    image: '/case3.png',
  },
  {
    slug: 'chromite-sweden-ferroalloy',
    title: 'Chromite concentrate to a Nordic ferro-alloy plant',
    client: 'A Swedish ferro-chrome producer',
    mineral: 'Chromite Concentrate (48% Cr₂O₃)',
    volume: '48,000 MT',
    origin: 'Sukinda → Paradip',
    destination: 'Oxelösund, Sweden',
    year: '2023',
    summary:
      'Handled the full chain including ore-to-concentrate upgrade, Cr:Fe ratio QC, and a winter-window charter plan avoiding Baltic-ice risk.',
    image: '/case4.png',
  },
  {
    slug: 'manganese-ore-south-africa',
    title: 'Manganese ore to a South African ferro-alloy group',
    client: 'A JSE-listed ferro-alloys group',
    mineral: 'Manganese Ore (42% Mn)',
    volume: '85,000 MT',
    origin: 'Balaghat → Mumbai',
    destination: 'Durban, South Africa',
    year: '2022',
    summary:
      'Sourced from a consortium of 3 Balaghat miners; our logistics team consolidated onto a single Handymax shipment, saving USD 6/MT vs. split-load option.',
    image: '/case5.png',
  },
];

export const certifications = [
  {
    code: 'ISO 9001:2015',
    name: 'Quality Management System',
    issuer: 'TÜV SÜD',
    year: '2015 (renewed 2024)',
    scope: 'Mining, processing, logistics & export operations',
  },
  {
    code: 'ISO 14001:2015',
    name: 'Environmental Management System',
    issuer: 'TÜV SÜD',
    year: '2017 (renewed 2024)',
    scope: 'All operating sites & logistics network',
  },
  {
    code: 'ISO 45001:2018',
    name: 'Occupational Health & Safety',
    issuer: 'BSI',
    year: '2020 (renewed 2024)',
    scope: 'Mine sites, haul routes & loading yards',
  },
  {
    code: 'MoEF & CC',
    name: 'Environmental Clearance',
    issuer: 'Ministry of Environment, India',
    year: 'Current',
    scope: 'All captive mining leases',
  },
  {
    code: 'IBM Registration',
    name: 'Indian Bureau of Mines',
    issuer: 'Government of India',
    year: 'Active',
    scope: 'All mineral categories',
  },
  {
    code: 'APEDA',
    name: 'Export House Registration',
    issuer: 'Ministry of Commerce, India',
    year: 'Active',
    scope: 'Mineral & allied product export',
  },
];

export const esgMetrics = [
  {
    iconName: 'TreePine',
    value: '1.2M+',
    label: 'Trees planted',
    description:
      'Native afforestation across buffer zones at 7 operating sites since 2016.',
    order: 1,
  },
  {
    iconName: 'Leaf',
    value: '480 ha',
    label: 'Land rehabilitated',
    description:
      'Post-mining land returned to productive forestry or agriculture, independently audited.',
    order: 2,
  },
  {
    iconName: 'Users',
    value: '18',
    label: 'Community programs',
    description:
      'Schools, skill centres, mobile clinics and women-led enterprise initiatives near mine sites.',
    order: 3,
  },
  {
    iconName: 'Gauge',
    value: '32%',
    label: 'Reduction in diesel intensity',
    description:
      'Vs. our 2019 baseline, through fleet modernisation, route optimisation and solar-powered site camps.',
    order: 4,
  },
];

export const esgCommitments = [
  {
    text: 'Zero untreated effluent discharge — closed-loop water circuits at every beneficiation plant',
    order: 1,
  },
  { text: 'Progressive mine closure plans filed for every active lease', order: 2 },
  { text: 'Mandatory safety training — 40+ hours/year for every operator', order: 3 },
  {
    text: 'Community grievance redressal within 72 hours, tracked publicly',
    order: 4,
  },
  { text: 'Carbon intensity disclosure aligned with GRI & BRSR standards', order: 5 },
];

export const faqs = [
  {
    q: 'What minerals do you export?',
    a: 'We export a wide range of minerals including thermal coal, iron ore (fines & lumps), bauxite, manganese ore, chromite concentrate and dolomite, sourced from partner mines across Odisha, Jharkhand and Chhattisgarh.',
    order: 1,
  },
  {
    q: 'Which ports do you operate from?',
    a: 'We primarily operate through Mumbai, Visakhapatnam and Chennai ports, with partner infrastructure at Paradip and Krishnapatnam for specialised cargo. We can also arrange loading at minor ports when the economics favour it.',
    order: 2,
  },
  {
    q: 'Do you provide logistics and transportation?',
    a: 'Yes — our in-house logistics team handles pit-to-port transportation with a dedicated fleet, rail tie-ins and real-time shipment tracking. Every consignment is visible through our 24/7 control tower.',
    order: 3,
  },
  {
    q: 'What documents are required for export?',
    a: 'Standard export documentation includes the Commercial Invoice, Packing List, Bill of Lading, Certificate of Origin, SGS/CCIC quality certificate and any country-specific compliance certificates. Our export desk handles the full paperwork.',
    order: 4,
  },
  {
    q: 'What minimum order quantities do you support?',
    a: 'Typical MOQs are 25,000 MT for bulk minerals and 500 MT for containerised cargo. We can go below those for sample or trial shipments — please raise the request via our contact form.',
    order: 5,
  },
  {
    q: 'How long does a typical shipment take?',
    a: 'Domestic pit-to-port moves are 3–7 days. Sea freight is destination-dependent: 7–12 days to South-East Asia, 18–24 days to Europe / Mediterranean, 25–30 days to the Americas. We share ETA updates at every stage.',
    order: 6,
  },
  {
    q: 'How can I get a quotation?',
    a: 'Fill in the Get in Touch form on this page with your requirement (mineral, grade, volume, destination port) and our team will respond within one business day with indicative pricing, available grades and earliest shipment window.',
    order: 7,
  },
];

export const leaders = [
  {
    name: 'Rajeev Mahadevan',
    title: 'Founder & Chief Executive Officer',
    image:
      'https://images.unsplash.com/photo-1560250097-0b93528c311a?auto=format&fit=crop&w=400&q=80',
    experience: '25+ years in mining & mineral export',
    bio: 'Rajeev founded JMKC in 1998 as a Kolkata-based mineral trader and has grown it into an integrated mining-to-export operation. A mining engineer by training, he spent the first ten years of his career on open-pit benches in Odisha before turning operator.',
    order: 1,
  },
  {
    name: 'Ananya Iyer',
    title: 'Chief Operating Officer',
    image:
      'https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?auto=format&fit=crop&w=400&q=80',
    experience: '18 years in operations & supply chain',
    bio: 'Ananya runs day-to-day operations across mines, logistics and the Kolkata control tower. Before joining JMKC in 2014, she led pit-to-port logistics at a top-three Indian steel major. She holds an MBA from IIM Bangalore.',
    order: 2,
  },
];

export const teamMembers = [
  {
    name: 'Vikram Singh Rathore',
    title: 'Head of Mining & Operations',
    image:
      'https://images.unsplash.com/photo-1519085360753-af0119f7cbe7?auto=format&fit=crop&w=400&q=80',
    order: 1,
  },
  {
    name: 'Priya Deshmukh',
    title: 'Head of Global Exports',
    image:
      'https://images.unsplash.com/photo-1580489944761-15a19d654956?auto=format&fit=crop&w=400&q=80',
    order: 2,
  },
  {
    name: 'Arjun Banerjee',
    title: 'Head of Sustainability & ESG',
    image:
      'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=400&q=80',
    order: 3,
  },
  {
    name: 'Meera Krishnan',
    title: 'Head of Finance',
    image:
      'https://images.unsplash.com/photo-1544005313-94ddf0286df2?auto=format&fit=crop&w=400&q=80',
    order: 4,
  },
  {
    name: 'Sanjay Patil',
    title: 'Head of Logistics',
    image:
      'https://images.unsplash.com/photo-1492562080023-ab3db95bfbce?auto=format&fit=crop&w=400&q=80',
    order: 5,
  },
  {
    name: 'Neha Agarwal',
    title: 'Head of Quality Assurance',
    image:
      'https://images.unsplash.com/photo-1487412720507-e7ab37603c6f?auto=format&fit=crop&w=400&q=80',
    order: 6,
  },
  {
    name: 'Rohan Mehta',
    title: 'Head of Manufacturing',
    image:
      'https://images.unsplash.com/photo-1506794778202-cad84cf45f1d?auto=format&fit=crop&w=400&q=80',
    order: 7,
  },
  {
    name: 'Kavita Joshi',
    title: 'Head of Human Resources',
    image:
      'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?auto=format&fit=crop&w=400&q=80',
    order: 8,
  },
];

export const milestones = [
  {
    year: '1998',
    title: 'JMKC founded',
    description:
      'Incorporated in Kolkata as a domestic mineral-trading firm, servicing power-sector buyers in eastern India.',
    order: 1,
  },
  {
    year: '2004',
    title: 'First mine lease',
    description:
      'Secured our first captive mining lease in Odisha for thermal coal, marking the shift from trader to integrated operator.',
    order: 2,
  },
  {
    year: '2010',
    title: 'First international shipment',
    description:
      'Shipped 35,000 MT of iron-ore fines to Jiangsu, China — the first of many cross-border consignments.',
    order: 3,
  },
  {
    year: '2015',
    title: 'ISO 9001 & 14001',
    description:
      "Certified for Quality and Environmental Management, formalising the operating standards we'd built over a decade.",
    order: 4,
  },
  {
    year: '2019',
    title: 'Logistics division launch',
    description:
      'Brought pit-to-port logistics in-house with a fleet of 120 trucks and rail tie-ins at three sidings.',
    order: 5,
  },
  {
    year: '2024',
    title: '15-country export footprint',
    description:
      'Routine deliveries to 15+ countries across Asia, Europe, Africa and the Middle East via 5 major Indian ports.',
    order: 6,
  },
];

export const processSteps = [
  {
    step: '01',
    title: 'Extract',
    iconName: 'Pickaxe',
    summary:
      'Controlled drilling, blasting and excavation at grade-tagged pit benches.',
    bullets: [
      'Geological modelling & drill-hole planning',
      'Pit optimisation for grade & stripping ratio',
      'Mine-dispatch system tracks every bucket',
    ],
    order: 1,
  },
  {
    step: '02',
    title: 'Process',
    iconName: 'Factory',
    summary:
      "On-site crushing, screening and washing tuned to the client's target spec.",
    bullets: [
      'Primary, secondary & tertiary crushers',
      'Dense-media separation for upgrade',
      'QC sampling at every stockpile transition',
    ],
    order: 2,
  },
  {
    step: '03',
    title: 'Transport',
    iconName: 'Truck',
    summary:
      'Pit-to-port haulage via our fleet, with rail tie-ins for long hauls.',
    bullets: [
      '200+ in-house tippers with GPS',
      'Rail sidings at 4 strategic loading points',
      'Bonded CFS warehousing pre-shipment',
    ],
    order: 3,
  },
  {
    step: '04',
    title: 'Load & Ship',
    iconName: 'Ship',
    summary:
      'Vessel chartering, stowage planning and SGS-verified load reports.',
    bullets: [
      'Capesize / Panamax / Handymax chartering',
      'Third-party draft surveys at load port',
      'Documentation dispatched within 24h of sailing',
    ],
    order: 4,
  },
  {
    step: '05',
    title: 'Deliver',
    iconName: 'PackageCheck',
    summary:
      'Discharge coordination, quality reconciliation and post-shipment support.',
    bullets: [
      'Discharge-port surveyor coordination',
      'Quality reconciliation vs. load certificate',
      'Post-shipment reporting & settlement support',
    ],
    order: 5,
  },
];

export const testimonials = [
  {
    name: 'Klaus Weber',
    title: 'Procurement Director, European Steel Co.',
    quote:
      "JMKC's QC discipline is the reason we keep coming back. Six consecutive Capesize shipments, zero reject, zero dispute. That kind of consistency is rare.",
    order: 1,
  },
  {
    name: 'Nguyen Thi Hoa',
    title: 'Senior Buyer, Vietnamese IPP',
    quote:
      'The stockpile monitoring dashboard was a small touch that built a lot of trust. We could see loading progress in real time from Hanoi.',
    order: 2,
  },
  {
    name: 'Ahmed Al-Mansoori',
    title: 'Head of Raw Materials, Gulf Aluminium Smelter',
    quote:
      "Their grade-control blending is genuinely best-in-class. We asked for 52% Al₂O₃ consistently and that's what we got — every shipment.",
    order: 3,
  },
  {
    name: 'Erik Lindqvist',
    title: 'Commercial Manager, Nordic Ferro-Alloy Producer',
    quote:
      'When Baltic weather threatened our winter window, the JMKC team re-chartered and rerouted in 72 hours. Real partnership behaviour.',
    order: 4,
  },
  {
    name: 'Moses Adeyemi',
    title: 'Director of Operations, West African Cement',
    quote:
      "They run a tight operation. Documentation is always complete first-time, which means our bank never holds our LC. That's worth real money.",
    order: 5,
  },
  {
    name: 'Sanjay Kapoor',
    title: 'GM Procurement, Domestic Power Major',
    quote:
      "We've been buying from JMKC since before they started exporting. The service level has scaled with them — which I didn't expect.",
    order: 6,
  },
  {
    name: 'Mikiko Tanaka',
    title: 'Commodities Buyer, Japanese Trading House',
    quote:
      "Tight specs, honest communication when things shift. That's what we look for and that's what we get.",
    order: 7,
  },
  {
    name: 'Lerato Molefe',
    title: 'Supply Chain Lead, South African Ferro-Alloys',
    quote:
      'The consolidated Handymax saved us USD 6/MT on that shipment. Their logistics team actually thinks about our P&L, not just theirs.',
    order: 8,
  },
];

export const jobs = [
  {
    slug: 'mining-engineer-odisha',
    title: 'Senior Mining Engineer',
    department: 'Mining Operations',
    location: 'Keonjhar, Odisha',
    type: 'Full-time' as const,
    experience: '6–10 years',
    salary: '₹18–28 LPA',
    postedOn: '2026-04-15',
    description:
      "Own pit planning, blast design and grade control at our flagship iron ore & chromite operation in Keonjhar. You'll work alongside a 200-strong mine crew and report to the Head of Mining.",
    responsibilities: [
      'Lead short and long-term mine planning (quarterly and 5-year)',
      'Own blast design, drill-pattern optimisation and powder factor',
      'Drive grade control with on-site QC sampling and reconciliation',
      'Coordinate with DGMS, IBM and state pollution boards on compliance',
    ],
    requirements: [
      'B.Tech / B.E. in Mining Engineering from a recognised institute',
      "DGMS First-Class Mine Manager's Certificate (metalliferous)",
      '6+ years in open-cast iron ore or chromite operations',
      'Proficiency with Surpac / Datamine / MineSched',
    ],
  },
  {
    slug: 'logistics-manager-kolkata',
    title: 'Logistics & Transport Manager',
    department: 'Logistics',
    location: 'Kolkata, West Bengal',
    type: 'Full-time' as const,
    experience: '5–8 years',
    salary: '₹14–20 LPA',
    postedOn: '2026-04-12',
    description:
      "Run the pit-to-port control tower for one of our primary corridors. You'll own fleet deployment, rake planning and port coordination for ~40 rakes per month.",
    responsibilities: [
      'Plan and dispatch daily truck fleet across 3 pit-head sidings',
      'Coordinate BOXN rake loading and railway indent planning',
      'Manage port handovers with stevedores at Paradip & Visakhapatnam',
      'Own KPIs for turnaround time, detention charges and on-time dispatch',
    ],
    requirements: [
      'MBA in Operations / Supply Chain or equivalent experience',
      '5+ years in bulk cargo logistics (mining / steel / power)',
      'Hands-on with FOIS, e-RR and port EDI systems',
      'Strong negotiation skills with transporters and port operators',
    ],
  },
  {
    slug: 'safety-officer-jharkhand',
    title: 'Safety Officer (DGMS)',
    department: 'HSE',
    location: 'Dhanbad, Jharkhand',
    type: 'Full-time' as const,
    experience: '3–6 years',
    salary: '₹9–14 LPA',
    postedOn: '2026-04-10',
    description:
      'Be the on-ground owner of safety at our Dhanbad thermal coal operation. Conduct daily audits, investigate incidents and drive the zero-harm programme with site leadership.',
    responsibilities: [
      'Conduct daily shift-safety briefings and unsafe-act audits',
      'Investigate incidents and close out CAPA items with timelines',
      'Maintain DGMS statutory registers and Form-I / Form-II filings',
      'Lead emergency response drills and firefighting readiness',
    ],
    requirements: [
      'Diploma / Degree in Mining or Safety Engineering',
      'DGMS Certificate of Competency — Safety Officer',
      '3+ years in an open-cast coal mine',
      'Familiarity with ISO 45001 audits',
    ],
  },
  {
    slug: 'heavy-equipment-operator',
    title: 'Heavy Equipment Operator (HEMM)',
    department: 'Mining Operations',
    location: 'Bailadila, Chhattisgarh',
    type: 'Full-time' as const,
    experience: '2–5 years',
    salary: '₹4.5–7 LPA',
    postedOn: '2026-04-08',
    description:
      'Operate Cat 777 / Komatsu HD-785 haul trucks and Liebherr 9250 excavators on our iron ore operation. Join a crew of 60 operators on a 12-hour rotating shift.',
    responsibilities: [
      'Operate haul trucks and excavators per shift production targets',
      'Complete pre-shift inspections and log defects on the telematics system',
      'Follow the mine traffic management plan and radio protocols',
      'Support operator training for new hires in the crew',
    ],
    requirements: [
      'Class III driving licence with HEMM endorsement',
      '2+ years operating 100T+ class haul trucks or excavators',
      'ITI Diploma preferred',
      'Willingness to work 12-hour rotating shifts at a remote site',
    ],
  },
  {
    slug: 'export-coordinator-mumbai',
    title: 'Export Coordinator',
    department: 'Trading & Export',
    location: 'Mumbai, Maharashtra',
    type: 'Full-time' as const,
    experience: '4–7 years',
    salary: '₹11–16 LPA',
    postedOn: '2026-04-05',
    description:
      "Coordinate end-to-end export shipments for iron ore, manganese and bauxite cargoes from Nhava Sheva and JNPT. You'll be the single point of contact between trading, logistics and the customs desk.",
    responsibilities: [
      'Prepare and file export documentation — Invoice, Packing List, BL, CoO',
      'Coordinate pre-shipment inspections with SGS / CCIC / Alex Stewart',
      'Liaise with CHAs and DGFT for customs clearance and duty drawback',
      'Track vessel loading, generate post-shipment reports for clients',
    ],
    requirements: [
      'Graduate with a diploma in Export Management or equivalent',
      '4+ years in bulk mineral export documentation',
      'Working knowledge of ICEGATE, DGFT and e-BRC systems',
      'APEDA / FIEO familiarity is a plus',
    ],
  },
  {
    slug: 'hr-manager-kolkata',
    title: 'HR Manager — Plant & Mines',
    department: 'Human Resources',
    location: 'Kolkata, West Bengal (with site travel)',
    type: 'Full-time' as const,
    experience: '7–10 years',
    salary: '₹16–22 LPA',
    postedOn: '2026-04-02',
    description:
      'Own the plant & mines HR function — from hiring site supervisors to IR, contract labour compliance and site-welfare programmes across 3 states.',
    responsibilities: [
      'Drive blue-collar hiring pipelines for 4 active mine sites',
      'Manage contract labour compliance under CLRA & state rules',
      'Lead IR interventions and unionised-workforce negotiations',
      'Roll out site welfare, housing and training programmes',
    ],
    requirements: [
      'MBA / PGDM in HR from a recognised institute',
      '7+ years in plant-HR / IR in mining, steel or heavy manufacturing',
      'Familiarity with the Mines Act 1952 and allied labour laws',
      'Willingness to travel ~8 days/month to remote sites',
    ],
  },
];
