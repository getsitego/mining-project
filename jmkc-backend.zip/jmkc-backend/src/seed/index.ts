import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import {
  minerals,
  services,
  caseStudies,
  certifications,
  esgMetrics,
  esgCommitments,
  faqs,
  leaders,
  teamMembers,
  milestones,
  processSteps,
  testimonials,
  jobs,
} from './data';

type StrapiCtx = { strapi: any };

const PUBLIC_DIR = path.resolve(process.cwd(), '..', 'mining-project', 'public');

const MIME_BY_EXT: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
};

function mimeFor(filename: string) {
  return MIME_BY_EXT[path.extname(filename).toLowerCase()] ?? 'application/octet-stream';
}

// Resolve a /public-relative path case-insensitively against the actual filesystem.
// services.ts references `/M3.jpg` but only `m3.jpg` exists on disk.
function resolvePublicPath(rel: string): string | null {
  const target = rel.replace(/^\/+/, '');
  try {
    const direct = path.join(PUBLIC_DIR, target);
    if (fs.existsSync(direct)) return direct;
    const lcTarget = target.toLowerCase();
    for (const entry of fs.readdirSync(PUBLIC_DIR)) {
      if (entry.toLowerCase() === lcTarget) return path.join(PUBLIC_DIR, entry);
    }
  } catch {
    return null;
  }
  return null;
}

async function uploadLocal(strapi: any, rel: string): Promise<number | null> {
  const abs = resolvePublicPath(rel);
  if (!abs) {
    strapi.log.warn(`[seed] missing local image: ${rel}`);
    return null;
  }
  const stats = fs.statSync(abs);
  const filename = path.basename(abs);
  const [file] = await strapi.plugin('upload').service('upload').upload({
    data: {},
    files: {
      filepath: abs,
      originalFilename: filename,
      mimetype: mimeFor(filename),
      size: stats.size,
    },
  });
  return file.id;
}

async function uploadRemote(strapi: any, url: string): Promise<number | null> {
  try {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    const buf = Buffer.from(await res.arrayBuffer());
    const tmpName = `unsplash-${Date.now()}-${Math.random().toString(36).slice(2)}.jpg`;
    const tmp = path.join(os.tmpdir(), tmpName);
    fs.writeFileSync(tmp, buf);
    const [file] = await strapi.plugin('upload').service('upload').upload({
      data: {},
      files: {
        filepath: tmp,
        originalFilename: tmpName,
        mimetype: 'image/jpeg',
        size: buf.length,
      },
    });
    fs.unlinkSync(tmp);
    return file.id;
  } catch (err: any) {
    strapi.log.warn(`[seed] failed to download remote image: ${url} (${err.message})`);
    return null;
  }
}

async function setPublicReadPermissions(strapi: any) {
  const types = [
    'mineral',
    'service',
    'case-study',
    'certification',
    'esg-metric',
    'esg-commitment',
    'faq',
    'leader',
    'team-member',
    'milestone',
    'process-step',
    'testimonial',
    'job',
  ];

  const publicRole = await strapi
    .query('plugin::users-permissions.role')
    .findOne({ where: { type: 'public' } });
  if (!publicRole) {
    strapi.log.warn('[seed] public role not found, skipping permission grant');
    return;
  }

  for (const t of types) {
    for (const action of ['find', 'findOne']) {
      const fullAction = `api::${t}.${t}.${action}`;
      const existing = await strapi
        .query('plugin::users-permissions.permission')
        .findOne({ where: { action: fullAction, role: publicRole.id } });
      if (existing) continue;
      await strapi.query('plugin::users-permissions.permission').create({
        data: { action: fullAction, role: publicRole.id },
      });
    }
  }
  strapi.log.info('[seed] public read permissions granted');
}

export async function seedAll({ strapi }: StrapiCtx) {
  const existingMinerals = await strapi.entityService.count('api::mineral.mineral');
  if (existingMinerals > 0) {
    strapi.log.info('[seed] minerals already present, skipping seed');
    await setPublicReadPermissions(strapi);
    return;
  }

  strapi.log.info('[seed] starting seed');

  // Phase 1: image upload — collect every unique local path and remote URL,
  // upload once, keep an id map for the create phase.
  const imageMap: Record<string, number> = {};
  const localPaths = new Set<string>();
  const remoteUrls = new Set<string>();
  for (const m of minerals) localPaths.add(m.image);
  for (const s of services) localPaths.add(s.image);
  for (const c of caseStudies) localPaths.add(c.image);
  for (const l of leaders) remoteUrls.add(l.image);
  for (const t of teamMembers) remoteUrls.add(t.image);

  for (const p of localPaths) {
    const id = await uploadLocal(strapi, p);
    if (id) imageMap[p] = id;
  }
  for (const u of remoteUrls) {
    const id = await uploadRemote(strapi, u);
    if (id) imageMap[u] = id;
  }

  // Phase 2: create entries.
  for (const m of minerals) {
    await strapi.entityService.create('api::mineral.mineral', {
      data: { ...m, image: imageMap[m.image] ?? null },
    });
  }
  for (const s of services) {
    await strapi.entityService.create('api::service.service', {
      data: { ...s, image: imageMap[s.image] ?? null },
    });
  }
  for (const c of caseStudies) {
    await strapi.entityService.create('api::case-study.case-study', {
      data: { ...c, image: imageMap[c.image] ?? null },
    });
  }
  for (const c of certifications) {
    await strapi.entityService.create('api::certification.certification', { data: c });
  }
  for (const m of esgMetrics) {
    await strapi.entityService.create('api::esg-metric.esg-metric', { data: m });
  }
  for (const c of esgCommitments) {
    await strapi.entityService.create('api::esg-commitment.esg-commitment', { data: c });
  }
  for (const f of faqs) {
    await strapi.entityService.create('api::faq.faq', { data: f });
  }
  for (const l of leaders) {
    await strapi.entityService.create('api::leader.leader', {
      data: { ...l, image: imageMap[l.image] ?? null },
    });
  }
  for (const t of teamMembers) {
    await strapi.entityService.create('api::team-member.team-member', {
      data: { ...t, image: imageMap[t.image] ?? null },
    });
  }
  for (const m of milestones) {
    await strapi.entityService.create('api::milestone.milestone', { data: m });
  }
  for (const p of processSteps) {
    await strapi.entityService.create('api::process-step.process-step', { data: p });
  }
  for (const t of testimonials) {
    await strapi.entityService.create('api::testimonial.testimonial', { data: t });
  }
  for (const j of jobs) {
    await strapi.entityService.create('api::job.job', { data: j });
  }

  await setPublicReadPermissions(strapi);
  strapi.log.info('[seed] seed complete');
}
