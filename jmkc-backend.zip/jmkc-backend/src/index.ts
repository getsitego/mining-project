import { seedAll } from './seed';

export default {
  register() {},

  async bootstrap({ strapi }: { strapi: any }) {
    try {
      await seedAll({ strapi });
    } catch (err: any) {
      strapi.log.error(`[seed] bootstrap seed failed: ${err.message}`);
      if (err.stack) strapi.log.error(err.stack);
    }
  },
};
