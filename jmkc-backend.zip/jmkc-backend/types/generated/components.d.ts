import type { Schema, Struct } from '@strapi/strapi';

export interface SpecsSpec extends Struct.ComponentSchema {
  collectionName: 'components_specs_specs';
  info: {
    description: 'Label/value pair for mineral specifications';
    displayName: 'Spec';
  };
  attributes: {
    label: Schema.Attribute.String & Schema.Attribute.Required;
    value: Schema.Attribute.String & Schema.Attribute.Required;
  };
}

declare module '@strapi/strapi' {
  export module Public {
    export interface ComponentSchemas {
      'specs.spec': SpecsSpec;
    }
  }
}
